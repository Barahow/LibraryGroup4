package model;

import java.util.ArrayList;

public class User {
        String name;
        String address;
        String SSN;
        String userName;
        String password;
        boolean member = true;
        private ArrayList<BorrowBook> borrowedBooks;

        public User(String name, String address, String SSN,
                    String userName, String password, boolean member, ArrayList<BorrowBook> borrowedBooks) {
            this.name = name;
            this.address = address;
            this.SSN = SSN;
            this.userName = userName;
            this.password = password;
            this.member = member;
            this.borrowedBooks = borrowedBooks;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getSSN() {
            return SSN;
        }

        public void setSSN(String SSN) {
            this.SSN = SSN;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public boolean isMember() {
            return member;
        }

        public void setMember(boolean member) {
            this.member = member;
        }

        public ArrayList<BorrowBook> getBorrowedBooks() {
            return borrowedBooks;
        }

        public void setBorrowedBooks(ArrayList<BorrowBook> borrowedBooks) {
            this.borrowedBooks = borrowedBooks;
        }
    }
