package AddBook;


import java.sql.*;

public class DBConnection {
    private static DBConnection conn;

    String sql = "jdbc:mysql://localhost:3306/seminar?user=root&password=root&useSSL=false"; //serverTimezone=UTC
    Connection connection;
    Statement statement;
    ResultSet resultSet;

    public void createConnection() {
        try {
            connection = DriverManager.getConnection(sql);
            statement = connection.createStatement();
            System.out.println("Connection success!");
        } catch (Exception e) {
            System.out.println("Oppsssss database fail the connection!!!");
            e.printStackTrace();
        }
    }
    public boolean executeQuery(String bookname){
        String st = "SELECT * FROM books;";

        try {
            resultSet = statement.executeQuery(st);

            while (resultSet.next()) {
                //System.out.println("Start");
                if (resultSet.getString(2).contains(bookname)) {
                    System.out.println(resultSet.getString(1) + ",   " + resultSet.getString(2));

                }

               /* if (resultSet.getString(2).contains(bookname.toLowerCase())) {
                    System.out.println(resultSet.getString(1) + ",   " + resultSet.getString(2));
                    //return;
                }*/

                //System.out.println(resultSet.getString(1) + ",   " + resultSet.getString(2));

            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
