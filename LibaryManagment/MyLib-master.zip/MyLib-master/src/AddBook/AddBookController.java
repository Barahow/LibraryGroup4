package AddBook;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class AddBookController implements Initializable {
    @FXML
    private TextField title;
    @FXML
    private TextField isbn;
    @FXML
    private TextField author;
    @FXML
    private TextField publisher;
    DBConnection conn = new DBConnection();
    @FXML
    public void addBook(){

    }
    @FXML
    public void displayBook(ActionEvent event){
        conn.createConnection();

        conn.executeQuery(title.getText());


    }
    @FXML
    public void removeBook(){

    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {


    }
}
